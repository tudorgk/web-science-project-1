Each file contains the monthly vaccination uptake for one vaccine. 

The files are stored as json objects formatted as: 
    a list of dates, "year-month", and 
    a list of vaccination uptake.
